(function(){
    function qs(sel, el) { return (el || document).querySelector(sel); }
    var data = (window.WhatnotCalcData && window.WhatnotCalcData.rates) ? window.WhatnotCalcData.rates : {};

    document.addEventListener('DOMContentLoaded', function(){
        var root = qs('.whatnot-calc');
        if(!root) return;

        // Email-related code removed

        var inputs = [
            qs('#whatnot-country', root),
            qs('#whatnot-category', root),
            qs('#whatnot-sale-price', root),
            qs('#whatnot-item-cost', root),
            qs('#whatnot-shipping-charge', root),
            qs('#whatnot-shipping-cost', root)
        ];

        var results = qs('#whatnot-results', root);
        var resWhatnot = qs('#res-whatnot', root);
        var resProcessing = qs('#res-processing', root);
        var resTotal = qs('#res-total', root);
        var resEarnings = qs('#res-earnings', root);
        var resProfit = qs('#res-profit', root);
        var resMargin = qs('#res-margin', root);
        var rateLabel = qs('#whatnot-rate-label', root);

        // Fields enabled by default
        results.style.display = 'block';

        inputs.forEach(function(i){ 
            if(!i) return; 
            i.addEventListener('input', calculate); 
            i.addEventListener('change', calculate); 
        });

        function formatCurrency(val, symbol){
            if(isNaN(val)) return '-';
            var fixed = Number(val).toFixed(2);
            return symbol + fixed;
        }

        function calculate(){
            var country = (qs('#whatnot-country', root).value || 'United States');
            var category = (qs('#whatnot-category', root).value || 'Standard');
            var sale = parseFloat(qs('#whatnot-sale-price', root).value) || 0;
            var itemCost = parseFloat(qs('#whatnot-item-cost', root).value) || 0;
            var shippingCharge = parseFloat(qs('#whatnot-shipping-charge', root).value) || 0; // buyer pays
            var shippingCost = parseFloat(qs('#whatnot-shipping-cost', root).value) || 0; // seller cost

            var rateObj = data[country] || data['United States'];
            var currency = (rateObj && rateObj.currency) ? rateObj.currency : '$';

            // Whatnot fee is percentage of sale price only
            var whatnotRate = (rateObj && rateObj.whatnot && rateObj.whatnot[category]) ? parseFloat(rateObj.whatnot[category]) : 0.08;
            var whatnotFee = sale * whatnotRate;
            var whatnotFeeRounded = Number(whatnotFee.toFixed(2));

            // Payment processing is applied to sale + shipping charge
            var proc = (rateObj && rateObj.processing) ? rateObj.processing : { rate: 0.029, fixed: 0.30 };
            var processingFee = ((sale + shippingCharge) * (proc.rate || 0)) + (proc.fixed || 0);
            var processingFeeRounded = Number(processingFee.toFixed(2));

            // Build totals using rounded components
            var totalFees = Number((whatnotFeeRounded + processingFeeRounded).toFixed(2));

            // Earnings = sale price - total fees
            var earnings = Number((sale - totalFees).toFixed(2));

            // Profit = earnings - item cost - shipping cost
            var profit = Number((earnings - itemCost - shippingCost).toFixed(2));

            var margin = 0;
            if(earnings !== 0){ margin = Number(((profit / earnings) * 100).toFixed(1)); }

            // Label rate
            var percentLabel = (whatnotRate * 100).toFixed(2).replace(/\.00$/, '');
            if(percentLabel.indexOf('.') !== -1 && percentLabel.length>4){ 
                percentLabel = parseFloat(percentLabel).toFixed(2); 
            }
            rateLabel.textContent = percentLabel + '%';

            resWhatnot.textContent = formatCurrency(whatnotFeeRounded, currency);
            resProcessing.textContent = formatCurrency(processingFeeRounded, currency);
            resTotal.textContent = formatCurrency(totalFees, currency);
            resEarnings.textContent = formatCurrency(earnings, currency);
            resProfit.textContent = formatCurrency(profit, currency);
            resMargin.textContent = margin + '%';

            [resEarnings,resProfit].forEach(function(el){ 
                el.classList.remove('positive','negative'); 
                var num = parseFloat(el.textContent.replace(/[^0-9.-]+/g,'')); 
                if(!isNaN(num) && num >= 0) el.classList.add('positive'); 
                else el.classList.add('negative'); 
            });
        }

        // Initial calculation on load
        calculate();
    });
})();
