(function(){
    function qs(sel, el) { return (el || document).querySelector(sel); }
    var data = (window.WhatnotCalcData && window.WhatnotCalcData.rates) ? window.WhatnotCalcData.rates : {};

    document.addEventListener('DOMContentLoaded', function(){
        var root = qs('.whatnot-calc');
        if(!root) return;

        var email = qs('#whatnot-email', root);
        var confirmBtn = qs('#whatnot-confirm-email', root);
        var clearBtn = qs('#whatnot-clear', root);

        var inputs = [
            qs('#whatnot-country', root),
            qs('#whatnot-category', root),
            qs('#whatnot-sale-price', root),
            qs('#whatnot-item-cost', root),
            qs('#whatnot-shipping-charge', root),
            qs('#whatnot-shipping-cost', root)
        ];

        var results = qs('#whatnot-results', root);
        var resWhatnot = qs('#res-whatnot', root);
        var resProcessing = qs('#res-processing', root);
        var resTotal = qs('#res-total', root);
        var resEarnings = qs('#res-earnings', root);
        var resProfit = qs('#res-profit', root);
        var resMargin = qs('#res-margin', root);
        var rateLabel = qs('#whatnot-rate-label', root);

        function setDisabledState(disabled){
            inputs.forEach(function(i){ if(i){ i.disabled = disabled; } });
            if(disabled){ root.classList.add('whatnot-disabled'); results.style.display = 'none'; }
            else { root.classList.remove('whatnot-disabled'); results.style.display = 'block'; }
        }

        // Try to restore confirmed email state from localStorage
        var savedEmail = localStorage.getItem('whatnot_email') || '';
        var confirmed = localStorage.getItem('whatnot_email_confirmed') === '1';
        if(savedEmail){ email.value = savedEmail; }
        if(confirmed && savedEmail){ confirmBtn.textContent = '✔ Email Confirmed'; confirmBtn.disabled = true; setDisabledState(false); }
        else { setDisabledState(true); }

        confirmBtn.addEventListener('click', function(){
            var val = email.value.trim();
            if(!val || !/\S+@\S+\.\S+/.test(val)){
                alert('Please enter a valid email to continue');
                return;
            }
            confirmBtn.textContent = '✔ Email Confirmed';
            confirmBtn.disabled = true;
            localStorage.setItem('whatnot_email', val);
            localStorage.setItem('whatnot_email_confirmed', '1');
            setDisabledState(false);
            calculate();
        });

        clearBtn.addEventListener('click', function(){
            email.value = '';
            confirmBtn.textContent = 'Confirm Email';
            confirmBtn.disabled = false;
            localStorage.removeItem('whatnot_email');
            localStorage.removeItem('whatnot_email_confirmed');
            inputs.forEach(function(i){ if(i){ if(i.type === 'checkbox') i.checked = false; else i.value = ''; } });
            setDisabledState(true);
            [resWhatnot,resProcessing,resTotal,resEarnings,resProfit,resMargin].forEach(function(el){ el.textContent='-'; el.classList.remove('positive','negative'); });
        });

        inputs.forEach(function(i){ if(!i) return; i.addEventListener('input', calculate); i.addEventListener('change', calculate); });

        function formatCurrency(val, symbol){
            if(isNaN(val)) return '-';
            var fixed = Number(val).toFixed(2);
            return symbol + fixed;
        }

        function calculate(){
            var country = (qs('#whatnot-country', root).value || 'United States');
            var category = (qs('#whatnot-category', root).value || 'Standard');
            var sale = parseFloat(qs('#whatnot-sale-price', root).value) || 0;
            var itemCost = parseFloat(qs('#whatnot-item-cost', root).value) || 0;
            var shippingCharge = parseFloat(qs('#whatnot-shipping-charge', root).value) || 0; // buyer pays
            var shippingCost = parseFloat(qs('#whatnot-shipping-cost', root).value) || 0; // seller cost

            var rateObj = data[country] || data['United States'];
            var currency = (rateObj && rateObj.currency) ? rateObj.currency : '$';

            // Whatnot fee is percentage of sale price only
            var whatnotRate = (rateObj && rateObj.whatnot && rateObj.whatnot[category]) ? parseFloat(rateObj.whatnot[category]) : 0.08;
            var whatnotFee = sale * whatnotRate;
            var whatnotFeeRounded = Number(whatnotFee.toFixed(2));

            // Payment processing is applied to sale + shipping charge
            var proc = (rateObj && rateObj.processing) ? rateObj.processing : { rate: 0.029, fixed: 0.30 };
            var processingFee = ((sale + shippingCharge) * (proc.rate || 0)) + (proc.fixed || 0);
            var processingFeeRounded = Number(processingFee.toFixed(2));

            // Build totals using rounded components (matches reference tool behavior)
            var totalFees = Number((whatnotFeeRounded + processingFeeRounded).toFixed(2));

            // Earnings = sale price - total fees (shipping charge is passed through, not included in earnings)
            var earnings = Number((sale - totalFees).toFixed(2));

            // Profit = earnings - item cost - shipping cost (seller's shipping cost)
            var profit = Number((earnings - itemCost - shippingCost).toFixed(2));

            var margin = 0;
            if(earnings !== 0){ margin = Number(((profit / earnings) * 100).toFixed(1)); }

            // Label rate (as %)
            var percentLabel = (whatnotRate * 100).toFixed(2).replace(/\.00$/, '');
            if(percentLabel.indexOf('.') !== -1 && percentLabel.length>4){ percentLabel = parseFloat(percentLabel).toFixed(2); }
            rateLabel.textContent = percentLabel + '%';

            resWhatnot.textContent = formatCurrency(whatnotFeeRounded, currency);
            resProcessing.textContent = formatCurrency(processingFeeRounded, currency);
            resTotal.textContent = formatCurrency(totalFees, currency);
            resEarnings.textContent = formatCurrency(earnings, currency);
            resProfit.textContent = formatCurrency(profit, currency);
            resMargin.textContent = margin + '%';

            [resEarnings,resProfit].forEach(function(el){ el.classList.remove('positive','negative'); var num = parseFloat(el.textContent.replace(/[^0-9.-]+/g,'')); if(!isNaN(num) && num >= 0) el.classList.add('positive'); else el.classList.add('negative'); });
        }

        // initial calc if restored
        if(!confirmBtn.disabled){ /* nothing */ } else { calculate(); }

    });
})();