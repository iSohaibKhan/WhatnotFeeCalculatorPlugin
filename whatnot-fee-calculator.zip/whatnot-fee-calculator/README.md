## README / Notes

* **Shortcode**: use `[whatnot_fee_calculator]` in any post/page/widget (text/html) to show the calculator.

* **Behavior**:

  * Email confirm required before inputs enable (same UX as your previous plugins). Confirmed email persists to `localStorage` so it remains confirmed on refresh.
  * Currency, Whatnot fee rates and processing fee rates come from the `whatnot_calc_rates` mapping and can be filtered via `add_filter('whatnot_calc_rates', ... )` in a theme/plugin.
  * **Whatnot fee** is applied to *item sale price only*.
  * **Payment Processing** is applied to *(item sale price + shipping charge)*.
  * **Total Fees** = (rounded Whatnot fee) + (rounded Processing fee). (Rounded components are used to match reference outputs.)
  * **Earnings** = Sale Price - Total Fees (shipping charge is treated as pass-through and does not change earnings).
  * **Profit** = Earnings - Item Cost - Shipping Cost (seller's shipping cost).
  * **Profit Margin** = (Profit / Earnings) \* 100 (rounded to 1 decimal).